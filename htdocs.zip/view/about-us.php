<?php $title = 'About Us'; ?>
<?php require_once('includes/alt-header.php'); ?>
    <section class="uk-section-large uk-padding">
      <div class="uk-container uk-text-center">
        <h2>About Us</h2>
        <hr class="uk-hr">
      </div>
      <div class="uk-grid-divider uk-child-width-expand@s uk-padding" uk-grid>
        <div>
          <h3 class="uk-text-bold"><span>Title</span></h3>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </div>
        <div>
          <h3 class="uk-text-bold"><span>Title 2</span></h3>
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
        <div>
          <h3 class="uk-text-bold"><span>Title 3</span></h3>
        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </div>
      </div>
    </section>
<?php require_once('includes/includes.footer.php'); ?>