<?php $title = 'Home'; ?>
<?php require_once('includes/includes.header.php'); ?>
    <section class="uk-margin-xlarge-top uk-container uk-container-small">
      <div class="uk-child-width-1-2 uk-grid-collapse populate-here" uk-grid="masonry: true">
        <!-- <div>
          <div class="uk-inline">
              <img src="../view/assets/img/products/2.jpg" alt="">
              <a href="product" class="blog-info" style="opacity: 0;">
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <h3>Product Name Here</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna...<hr class="uk-hr">Click read more...</p>
                </div>
              </a>
          </div>
        </div>
        <div>
          <div class="uk-inline">
              <img src="../view/assets/img/products/2.jpg" alt="">
              <a href="product" class="blog-info" style="opacity: 0;">
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <h3>Product Name Here</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna...<hr class="uk-hr">Click read more...</p>
                </div>
              </a>
          </div>
        </div>
        <div>
          <div class="uk-inline">
              <img src="../view/assets/img/products/1.jpg" alt="">
              <a href="product" class="blog-info" style="opacity: 0;">
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <h3>Product Name Here</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna...<hr class="uk-hr">Click read more...</p>
                </div>
              </a>
          </div>
        </div>
        <div>
          <div class="uk-inline">
              <img src="../view/assets/img/products/3.jpg" alt="">
              <a href="product" class="blog-info" style="opacity: 0;">
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <h3>Product Name Here</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna...<hr class="uk-hr">Click read more...</p>
                </div>
              </a>
          </div>
        </div>
        <div>
          <div class="uk-inline">
              <img src="../view/assets/img/products/4.jpg" alt="">
              <a href="product" class="blog-info" style="opacity: 0;">
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <h3>Product Name Here</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna...<hr class="uk-divider-icon">Click read more...</p>
                </div>
              </a>
          </div>
        </div>
        <div>
          <div class="uk-inline">
              <img src="../view/assets/img/products/5.jpg" alt="">
              <a href="product" class="blog-info" style="opacity: 0;">
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <h3>Product Name Here</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna...<hr class="uk-hr">Click read more...</p>
                </div>
              </a>
          </div>
        </div> -->
      </div>
    </section>
<?php require_once('includes/includes.footer.php'); ?>